#!/system/bin/sh
# Cogan Smart Kernel: put CPU speed and charging back, stop the log and the APK block, remove settings, history
# and whitelists.
# Logs saved to Download stay with the user.
MODDIR=${0%/*}; [ "$MODDIR" = "$0" ] && MODDIR=.
sh "$MODDIR/manager/report.sh" reset >/dev/null 2>&1
sh "$MODDIR/manager/report.sh" clear-init >/dev/null 2>&1
rm -rf "${CS_ADB:-/data/adb}/cogan_smart/manager"
sh "$MODDIR/power/uninstall.sh"
sh "$MODDIR/thermal/uninstall.sh"
rm -rf "${CS_ADB:-/data/adb}/cogan_smart/guard"
sh "$MODDIR/apps/report.sh" stop >/dev/null 2>&1
rm -rf "${CS_ADB:-/data/adb}/cogan_smart/apps"
rmdir "${CS_ADB:-/data/adb}/cogan_smart" 2>/dev/null
exit 0
