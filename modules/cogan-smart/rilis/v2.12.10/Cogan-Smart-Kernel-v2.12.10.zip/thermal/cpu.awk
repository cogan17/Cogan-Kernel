# Cogan Smart · Thermal: CPU use since the previous sample.
# Files: <previous /proc/[pid]/stat lines> <current lines>; -v prev=<old /proc/stat cpu line> -v cur=<new one>,
# -v mods="<pid> ..." (this module's own long-running scripts: recorder, power controller, APK block),
# -v ctl=<pid> (the power controller, one of them).
# Prints "C <cpu%x10> <kernel%x10>" (-1 without a previous reading, -2 when the counters started again: the
# phone restarted), "M <module%x10> <controller%x10>", then "P <pct x10> <pid> <comm> <start>"
# for the 5 busiest user processes (start: start time, which tells a reused pid apart). -v partial=1: one of the
# two lists holds only the module's processes (a light sample, see sampler.sh): kernel is -1 and no P lines. The module's share
# counts its scripts and every child they already waited for (awk, cat, dumpsys...), which a per-process
# list misses because those end between two samples.
function total(line,   a, n, i, t) { n = split(line, a, " "); t = 0; for (i = 2; i <= n; i++) t += a[i]; return t }
function idle(line,   a) { split(line, a, " "); return a[5] + a[6] }
function parse(line,   o, c, k, rest, f) {
    o = index(line, "("); c = 0
    while ((k = index(substr(line, c + 1), ")")) > 0) c += k      # the last ")" ends the name
    if (!o || c <= o) return 0
    PID = substr(line, 1, o - 2) + 0
    COMM = substr(line, o + 1, c - o - 1)
    rest = substr(line, c + 2)
    split(rest, f, " ")
    PPID = f[2] + 0; TICKS = f[12] + f[13]; TREE = TICKS + f[14] + f[15]; START = f[20]
    return 1
}
FILENAME == ARGV[1] { if (parse($0)) { before[PID] = TICKS; tree[PID] = TREE }; next }
{
    if (!parse($0) || !(PID in before)) next
    if (index(" " mods " ", " " PID " ") && TREE > tree[PID]) {
        module += TREE - tree[PID]
        if (PID == ctl) control += TREE - tree[PID]
    }
    d = TICKS - before[PID]
    if (d <= 0) next
    if (PID == 2 || PPID == 2) { kernel += d; next }            # kernel threads (children of kthreadd)
    gsub(/[^A-Za-z0-9_.+-]/, "_", COMM)
    for (i = 1; i <= 5; i++) if (!(i in top) || d > top[i]) {
        for (j = 5; j > i; j--) if ((j - 1) in top) { top[j] = top[j - 1]; tpid[j] = tpid[j - 1]; tcomm[j] = tcomm[j - 1]; tstart[j] = tstart[j - 1] }
        top[i] = d; tpid[i] = PID; tcomm[i] = COMM; tstart[i] = START; break
    }
}
END {
    dt = total(cur) - total(prev)
    if (prev == "" || dt <= 0) { print "C " (prev != "" && dt < 0 ? -2 : -1) " -1"; exit }
    busy = dt - (idle(cur) - idle(prev))
    printf "C %d %d\n", int(busy * 1000 / dt + 0.5), (partial ? -1 : int(kernel * 1000 / dt + 0.5))
    printf "M %d %d\n", int(module * 1000 / dt + 0.5), int(control * 1000 / dt + 0.5)
    if (partial) exit
    for (i = 1; i <= 5; i++) if (i in top) printf "P %d %d %s %s\n", int(top[i] * 1000 / dt + 0.5), tpid[i], tcomm[i], tstart[i]
}
